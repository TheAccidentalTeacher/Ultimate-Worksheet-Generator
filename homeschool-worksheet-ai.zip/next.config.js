/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['images.pexels.com', 'pixabay.com', 'openclipart.org'],
  },
}
module.exports = nextConfig
